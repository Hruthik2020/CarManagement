export class Car {

    id: number;
    carName: string;
    carCmp: string;
    carOwner: string;
    
}
