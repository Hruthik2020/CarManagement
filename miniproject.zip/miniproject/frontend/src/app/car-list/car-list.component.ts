import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Car } from '../car';
import { CarService } from '../car.service';

@Component({
  selector: 'app-car-list',
  templateUrl: './car-list.component.html',
  styleUrls: ['./car-list.component.css']
})
export class CarListComponent implements OnInit {

  cars: Car[];

  constructor(private carservice: CarService,
    private router: Router) { }

  ngOnInit(): void {
    this.getCars();
    }

    private getCars(){
      this.carservice.getCarList().subscribe(data => {
        this.cars = data;
      });
    }  

    updateCar(id: number){
      this.router.navigate(['update-car',id]);

    }
 }
    
  
