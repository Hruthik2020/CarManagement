import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { error } from 'console';
import { Car } from '../car';
import { CarService } from '../car.service';

@Component({
  selector: 'app-update-car',
  templateUrl: './update-car.component.html',
  styleUrls: ['./update-car.component.css']
})
export class UpdateCarComponent implements OnInit {
  
  id: number;
  car: Car = new Car();
  constructor(private carService: CarService,
    private route:ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
  }

  goToCarList(){
    this.router.navigate(['/cars']);
  }

}
