package com.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.exception.ResourceNotFoundException;
import com.test.model.Car;
import com.test.repository.CarRepository;

@CrossOrigin(origins = "http://localhost:4200/")
@RestController
@RequestMapping("/api/v1/")
public class CarController {
	
	@Autowired
	private CarRepository carRepository;
	
	@GetMapping("/cars")
	public List<Car>getAllCars(){
		return carRepository.findAll();
	}
	
	@PostMapping("/cars")
	public Car createCar(@RequestBody Car car) {
		return carRepository.save(car);
	}
	
	@GetMapping("/cars/{id}")
	public ResponseEntity<Car> getCarById(@PathVariable Long id) {
		
		Car car = carRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Car not exist with id :" + id));
		return ResponseEntity.ok(car);
		
	}
	
	@PutMapping("/cars/{id}")
	public ResponseEntity<Car> updateCar(@PathVariable Long id, @RequestBody Car carDetails){
		
		Car car = carRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Car not exist with id :" + id));
		
		car.setCarName(carDetails.getCarName());
		car.setCarCmp( carDetails.getCarCmp());
		car.setCarOwner(carDetails.getCarOwner());
		
		Car updatedCar = carRepository.save(car);
		return ResponseEntity.ok(updatedCar);
	}
}
